<div class="nav-scroller py-1 mb-2">
  <nav class="nav d-flex justify-content-between" id="a_hover">
    <a class="p-2 link-secondary" href="index.php" style="text-decoration: none;">Trang chủ</a>
    <?php
          $data = $this->Model->fetch("select * from menu_catalog");
          
          foreach ($data as $gt2) {
      ?>   
    <a class="p-2 link-secondary" href="index.php?controller=topicBlog&id=<?php echo $gt2["id"]?>" style="text-decoration: none;"> 
                  <?php
                      echo $gt2["name"];
                  ?></a>  <?php } ?>
    
    
  </nav>
</div>
<br>

<div class="row">
    <div class="col-md-8">
    	<div class="row">
    		<!--post start-->
    		<div class="col-md-12">  
    			<article class="post hentry">
                    <div class="thumbnails">
                        <img src="<?php echo $value["avatar"] ?>" class="post-thumbnail img-responsive" width="100%" />
                    </div>
    				<div class="post-content-area">
    					<header class="entry-header text-center">
                            <div class="post-cat">
                            	<a href="#" rel="category tag">
                            		<?php
                            			$key = $this->Model->fetchOne("select * from menu_catalog where id=".$value["catalog"]);
                            			if(isset($key["name"]))
                            				echo $key["name"];
                            		?>
                            	</a>
                            </div>
                        	<div class="entry-title" style="font-weight: 600px; font-size: 24px;">
                        		<?php echo $value["name"] ?>
                        	</div>  
    					</header>
                        <!--/.entry-header -->
    					<div class="entry-content">
    						<span style="font-style: italic"><?php echo $value["description"] ?></span>
        					<p style="margin-top: 20px;">
                                <b>Nội dung chính: </b> <br>
        						<?php echo $value["content"] ?>
        					</p>
                    	</div>
                        <!-- .entry-content -->
                    	<div class="entry-meta text-center">
                    		<div class="share-this hidden-xs">
                    			<?php echo $value["dateTime"] ?>
                    		</div>
                        </div>
                        <!-- .entry-meta -->
    				</div>
    		    </article>
    		</div>
    		<!--/post end-->
    	</div>
    </div>
    <!-- /col -->

    <!--sidebar start-->
    <div class="col-md-4" style="padding-left:90px">
        <div class="primary-sidebar widget-area" role="complementary">

            <!-- bai viet lien quan -->
            <aside class="widget">
            <h4 class="pb-4 mb-4 font-italic border-bottom" style="text-align:center">Bài viết liên quan</h4>
                <div class="latest-posts latest">
                    <?php
                        $data = $this->Model->fetch("select * from menu_list_blog where catalog=".$value['catalog']." and id != '$id' limit 4");
                        foreach ($data as $blog) { 
                    ?>
                    <div class="media">
                        <!-- Chèn ảnh bài viết liên quan -->
                        <div class="latest-post-thumb">
                            <img src="<?php echo $blog["avatar"] ?>" class="img-responsive" width="100%" />
                        </div>

                        <div class="media-body">
                            <!-- Chèn tên chủ đề -->
                            <div class="entry-meta">
                                <a href="index.php?controller=topicBlog&id=<?php echo $blog["id"]?>" rel="category tag" style="text-decoration:none;">
                                    <?php
                                        $catalog = $this->Model->fetchOne("select * from menu_catalog where id=".$blog["catalog"]);
                                        if(isset($catalog["name"]))
                                            echo $catalog["name"];
                                    ?>
                                </a>
                            </div>
                            <!-- Chèn tên bài blog -->
                            <h5 class="entry-title">
                                <a  style="text-decoration:none;" href="index.php?controller=detailBlog&id=<?php echo $blog["id"] ?>"><?php echo $blog["name"] ?></a>
                            </h5>
                        </div>
                        <br><br>
                    </div>
                    <?php } ?>
                </div>
            </aside>
           

        </div>
    </div>
    <!--sidebar end-->
</div>