<div>

<p> <strong style="color:blue">Tổng số chủ đề của Blog:   </strong>
    <?php
         $total2 = $this->Model->count("select * from menu_catalog");                
         echo $total2; 
         ?></p>
    <?php 
        $dataCatalog= $this->Model->fetch("select * from menu_catalog");  
        foreach($dataCatalog as $dtC){
    ?>
<p> <strong>Tổng số bài viết của chủ đề <b style="color:green"><?php echo $dtC["name"]   ?> </b>là:   </strong>
     <?php
        // $total3 = $this->Model->count("select * from menu_list_blog where catalog=".$dtC['id']"");       
        $total3 = $this->Model->count("select * from menu_list_blog where catalog=".$dtC['id']);
         
         echo $total3; 
         ?></p>

<?php }?>

</div>
        