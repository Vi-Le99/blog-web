<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Chủ đề bài viết
        </h1>
    </div>
</div>
<div class="row">
		<div class="panel panel-primary">
			<div class="panel-heading">Thêm chủ đề</div>
			<div class="panel-body">
				<form action="index.php?controller=catalog_blog/list&act=add" method="post" enctype="multipart/form-data">
					<input type="text" name="topic" class="form-control" placeholder="Tên chủ đề"><br>
					<label for="">Chọn ảnh cho chủ đề </label>
					<input type="file" name="image" style="padding-top: 10px;"><br>
						
					<input type="text" name="moTa" class="form-control"  placeholder="Mô tả nội dung chủ đề" />
					<input type="submit" value="Thêm" class="btn btn-primary" style="margin-top: 5px;">
				</form>
			</div>
		</div>
	</div>
<div class="row">
	
		<div class="panel panel-success">
			<div class="panel-heading">Danh sách chủ đề</div>
			<div class="panel-body">
				<table class="table table-bordered table-hover">
					<tr>
						<td width="40px;">STT</td>
						<td width="200px;">Name</td>
						<td>Meta title</td>
						<td>Short describe</td>
						<td>image</td>
						<td width="80px">More</td>
					</tr>
					<?php
						$stt=0;
						foreach ($data as $value) { 
							$stt++;
					?>
					<tr>
						<td style="text-align: center;"><?php echo $stt; ?></td>
						<td><?php echo $value["name"] ?></td>
						<td><?php echo $value["metaTitle"] ?></td>
						<td><?php echo $value["moTa"] ?></td>
						<td><img src="../<?php echo $value["anh"] ?>" alt="Error" width="110px"></td>
						<td>
							<a href="index.php?controller=catalog_blog/edit&id=<?php echo $value["id"];?>">Update</a>
							<a href="index.php?controller=catalog_blog/list&id=<?php echo $value["id"];?>&act=delete">Delete</a>
						</td>
					</tr>
					<?php } ?>
				</table>
			</div>
		
	</div>
	
	
</div>